package mjk.ontology;

public class visitorrdf {

}
