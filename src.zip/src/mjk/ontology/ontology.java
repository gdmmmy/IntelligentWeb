package mjk.ontology;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class ontology {
	public ontology(){
	OntModel ontModel = ModelFactory.createOntologyModel();
//	OntModel m = ModelFactory.createOntologyModel(RDFS_MEM);
}
}
