package mjk.model;

public class Snippet {
	

	
}

