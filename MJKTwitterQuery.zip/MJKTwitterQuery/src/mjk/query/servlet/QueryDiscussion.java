package mjk.query.servlet;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import twitter4j.Twitter;
import mjk.twitter.*;
/**
 * Servlet implementation class QueryDiscussion
 */
public class QueryDiscussion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryDiscussion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String jsonpack = "This is a test";
		System.out.println("!");
//		System.out.println(request.getContentType());
		PrintWriter out = response.getWriter();
		String keywords=request.getParameter("key");
		String lattitude=request.getParameter("lat");
		String longitude=request.getParameter("lon");
		
		Specific_discussion tt = new Specific_discussion();
		
		InitConnectionTwitter ti = new InitConnectionTwitter();
	
		Twitter twitterConnection = null;
		
		try {
			
			twitterConnection= ti.init();
			
			jsonpack=tt.getSimpleTimeLine(twitterConnection,keywords,lattitude,longitude);
			
			System.out.println(jsonpack);
			} catch (Exception e) {
			System.out.println("Cannot initialise Twitter");
			e.printStackTrace();
			}
		
		response.setContentType("discussion/json");
		response.setCharacterEncoding("UTF-8");
		out.write(jsonpack);
	}
}
