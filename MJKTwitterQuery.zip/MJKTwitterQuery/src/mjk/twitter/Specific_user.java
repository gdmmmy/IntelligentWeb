package mjk.twitter;
import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.examples.async.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import com.google.gson.Gson;

import mjk.model.DatabaseConnection;
import net.sf.json.JSONArray;
public class Specific_user {
	
	public String getspecificuser(Twitter twitter, int number, int day, String user,ServletContext context) throws IOException, SQLException
	{
		this.context = context;   // get the text from servlet
		ArrayList<String> CountingResult = new ArrayList();  // used to get the word frequency array
		Map<String, ArrayList<String>> Temp = new HashMap(); // uesed to get a map with username and 
															// word frequency
		List<String> total = new ArrayList();    // this is the total frequency list
		Map<String, List<String>> TotalResult = new HashMap();
		// the map is used to store the word frequency after sorting
		String userinput = user;
		String [] username = userinput.split(",");    // handle the input username
		database = new DatabaseConnection();
		for(int i=0;i<username.length;i++)    
		{
			CountingResult = getfrequency(twitter,username[i],day);   
			Temp.put(username[i], CountingResult);
		}
		
		// sort the total frequency
		total = GetRank(TotalFrequency,number);
		
		// get the output of word frequency of each user
		TotalResult=GetTopWord(Temp,total,username);
		for(int i=0;i<username.length;i++)
		{
			String str = username[i].toString();
			// adjust the word frequency map to arraylist
			Map<String, List<String>> TempMap = new HashMap();
			
			TotalResult.get(str).add(0, str);
			TempMap.put("frequency", TotalResult.get(str));
			// put the new map into an jsonarray
			JsonArray.add(TempMap);
			
		}
		Map<String, List<String>> TempMap = new HashMap();
		// create total frequency map
		total.add(0, "total");
		TempMap.put("frequency", total);
		JsonArray.add(TempMap);
		// make it jsonarray
		Gson gson = new Gson(); 
		jsonpack = gson.toJson(JsonArray);
		
		// put each piece of data into a map, and then connect them to an arraylist. at last. 
		// change it to jsonstring
		
		return jsonpack;
	}
	
	public ArrayList getfrequency(Twitter twitter, String screenname, int day) throws IOException, SQLException
	{// this method is to get the frequency of words for one user
		String username=null;
		String whole_tweet="";
		Calendar c=new GregorianCalendar();
		c.add(c.DAY_OF_MONTH, -day);
		

		int y = c.get(c.YEAR);
		int m = c.get(c.MONTH)+1;
		int d =c.get(c.DAY_OF_MONTH);
		String date = y+"-"+m+"-"+d;
		try {
			// it creates a query and sets the geocode
			//requirement
			
			Query query = new Query("from:"+screenname+" since:"+date);

			//query1.setGeoCode(new GeoLocation(53.383, -1.483), 10,Query.KILOMETERS);
			query.setCount(100);  // ��������
			
			//it fires the query
			QueryResult result = twitter.search(query);

			//it cycles on the tweets
			List<Status> tweets = result.getTweets();
			
			
			long time = System.currentTimeMillis();
			//System.out.println(time);
			for (Status tweet : tweets) 
			{ ///gets the user
				User user = tweet.getUser();
				
				// calculate the time of the tweets 

				
					if(tweet.isRetweet()==false)
					{
						// Get all the tweets of one user together in order to count word frequency
						whole_tweet = whole_tweet + " " + tweet.getText();
						// Insert to the database
						String user_screenname = String.valueOf(user.getScreenName());
						String tweet_time = String.valueOf(tweet.getCreatedAt());
						String tweet_sid = String.valueOf(tweet.getId());
						database.InsertTweets(user_screenname, tweet.getText(), tweet_time, tweet_sid, "0");
						database.InsertUsers(user.getName(), user.getScreenName(), user.getLocation(),
								user.getProfileImageURL(), user.getDescription());
						UsersTweets(twitter,user.getScreenName());
					}
					username = user.getScreenName();
				
			
				
			}

		}
			catch (Exception te) 
			{
				te.printStackTrace();
				System.out.println("Failed to search tweets:" +
				te.getMessage());
				System.exit(-1);
			}
			return WordCounting(username,whole_tweet);
	
		}

	public ArrayList WordCounting(String n, String c) throws IOException
	{
		// handle the content of tweets
		ArrayList<String> result = new ArrayList();
		String text = c.toLowerCase();
		text = text.substring(1,text.length());
		text = text.replace("#", "");
		text = text.replace(",", "");
		text = text.replace(":", "");
		text = text.replace(".", "");
		text = text.replace("?", "");
		text = text.replace("!", "");
		text = text.replace("(", "");
		text = text.replace(")", "");
		text = text.replace(":", "");
		text = text.replace("-", "");
		text = text.replace("rt ", "");
		
		// create the stop_list
		InputStream is = context.getResourceAsStream("WEB-INF/stop_list.txt");
		BufferedReader br=new BufferedReader(new InputStreamReader(is));

		String listword = br.readLine();
		while(listword!=null)
		{
			StopList.add(listword);
			listword = br.readLine();
		}

		String [] word = text.toString().split(" ");
		
		
		for(int i=0;i<word.length;i++)    
		{
			if(!word[i].equals(""))    
			{
				if(!TotalFrequency.contains(word[i].toString()))
				{// if this word is not in the list, add it and set the frequency as 1
					if(!StopList.contains(word[i].toString()))  
					{
						// totalfrequency is an arraylist of all the words
						TotalFrequency.add(word[i].toString());   
						TotalFrequency.add("1");
					}
					
				}
				
				else
				{// it the word is already in the list, add one to the frequency
					if(TotalFrequency.indexOf(word[i].toString())%2==0)
					{
						
						int item = TotalFrequency.indexOf(word[i].toString());
						
						TotalFrequency.set(item+1, String.valueOf((Integer.valueOf(TotalFrequency.get(item+1)))+1));
					}
					else
					{
						TotalFrequency.add(word[i].toString());
						
						TotalFrequency.add("1");
					}
				}
				
				if(!result.contains(word[i].toString()))
				{// get the word frequency of each user
					if(!StopList.contains(word[i].toString()))
					{
						result.add(word[i].toString());
						result.add("1");
					}
				}
				
				else
				{
					if(result.indexOf(word[i].toString())%2==0)
					{
						
						int item = result.indexOf(word[i].toString());
						
						result.set(item+1, String.valueOf((Integer.valueOf(result.get(item+1)))+1));
					}
					else
					{
						result.add(word[i].toString());
						
						result.add("1");
					}
				}
			}
		}
	
		//CountingResult.put(n, result);
		return result;
	}
	
	public List GetRank(ArrayList<String> total, int n)
	{// sort the frequency
		String tempword=null, tempcount=null;
		for(int i=1;i<total.size()-2;i=i+2)
		{
			for(int j=1;j<total.size()-2-i;j=j+2)
			if(Integer.valueOf(total.get(j))<Integer.valueOf(total.get(j+2)))
			{ // if the frequency of latter word is bigger than that of former one, 
				// exchange their sequence
				
				tempword = total.get(j-1);
				total.set(j-1, total.get(j+1));
				total.set(j+1,tempword);
				tempcount = total.get(j);
				total.set(j, total.get(j+2));
				total.set(j+2,tempcount);
			}
		}

		List<String> output = total.subList(0, 2*n);
		
		return output;
	}
	
	public Map GetTopWord(Map m, List l, String[] s)
	{// get the word and frequency which are needed
		Map<String, ArrayList<String>> TempMap = new HashMap();
		TempMap=m;
		List<String> TempList = new ArrayList();
		TempList=l;
		String []username = s;
		for(int i=0;i<username.length;i++)
		{
			ArrayList<String> Temp = new ArrayList();
			String str = username[i].toString();
			for(int j=0;j<l.size();j=j+2)
			{
				// if this word is in the total list, add it to the map
				if(TempMap.get(str).contains(TempList.get(j)))
				{  
					int t = TempMap.get(str).indexOf(l.get(j));
					Temp.add(TempMap.get(str).get(t));
					Temp.add(TempMap.get(str).get(t+1));
				}
				else
				{
					Temp.add(TempList.get(j).toString());
					Temp.add("0");
				}
			}
			
			TempMap.get(str).clear();
			TempMap.get(str).addAll(Temp);
			
		}
		
		return TempMap;
	}
	
	
	public void UsersTweets(Twitter twitter,String userscreenname) throws SQLException, TwitterException
	{
		DatabaseConnection database = new DatabaseConnection();   
		Query query= new Query("from:"+userscreenname);
		
		query.setCount(100);  // number of limiting the query 
		
		QueryResult result = twitter.search(query);
		
		//it cycles on the tweets
		List<Status> tweets = result.getTweets();
		
		
		for (Status tweet : tweets) 
		{ ///gets the user
			User user = tweet.getUser();
			
			String user_screenname = String.valueOf(user.getScreenName());
			String tweet_time = String.valueOf(tweet.getCreatedAt());
			String tweet_sid = String.valueOf(tweet.getId());
			String tweet_isretweet = null;
			if(tweet.isRetweet() == true)
				tweet_isretweet = "1";
			else
				tweet_isretweet = "0";
			database.InsertTweets(user_screenname, tweet.getText(), tweet_time, tweet_sid, tweet_isretweet);
		}
		
	}
	
	private DatabaseConnection database;
	private ServletContext context;
	
	private ArrayList<String> StopList = new ArrayList();
	private ArrayList<String> TotalFrequency = new ArrayList();
	private ArrayList<Map> JsonArray = new ArrayList();
	private String jsonpack;
}
