package mjk.twitter;


import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mjk.model.DatabaseConnection;
import net.sf.json.JSONArray;

import com.google.gson.Gson;

public class Specific_discussion {

		
		public String getSimpleTimeLine(Twitter twitter, String keyword, String latitude, String longitude) throws SQLException
		{
			
			DatabaseConnection database = new DatabaseConnection();   
			
			try {
				// it creates a query and sets the geocode

				Query query= new Query(keyword);
				
				// if the latitude and longitude are not null, set the location
				if(latitude !="" && longitude !="")
					query.setGeoCode(new GeoLocation(Long.valueOf(latitude), Long.valueOf(longitude)), 20,Query.KILOMETERS);
				//it fires the query
				
				query.setCount(100);  // number of limiting the query 
				
				QueryResult result = twitter.search(query);
				
				//it cycles on the tweets
				List<Status> tweets = result.getTweets();
				
				
				for (Status tweet : tweets) 
				{ ///gets the user
					User user = tweet.getUser();
					
					ArrayList<String> retweetinfo = new ArrayList();  
					// This arraylist is used to store the information of a tweet which is retweeted
					Map<String, ArrayList<String>> queryinfo = new HashMap();
						if(tweet.isRetweet()==false)
						{
							// Insert to the database
							retweetinfo.add(tweet.getText());// put the text of tweet into arraylist
							String user_screenname = String.valueOf(user.getScreenName());
							String tweet_time = String.valueOf(tweet.getCreatedAt());
							String tweet_sid = String.valueOf(tweet.getId());
							String tweet_isretweet = null;
							if(tweet.isRetweet() == true)
								tweet_isretweet = "1";
							else
								tweet_isretweet = "0";
							database.InsertTweets(user_screenname, tweet.getText(), tweet_time, tweet_sid, tweet_isretweet);
							
							// Find retweeters
								List<Status> tweets1 = twitter.getRetweets(tweet.getId());
							// Use the ID of the tweet to search again and get retweets
							for (Status tweet1 : tweets1) 
							{
								
								User user1 = tweet1.getUser();
								
								if(tweet1.isRetweet()==true)
								{// if this tweet is retweet and get its username
									if(retweetinfo.size()<10)
									{
										retweetinfo.add(user1.getScreenName()); // store username into arraylist
										database.InsertUsers(user1.getName(),user1.getScreenName(), user1.getLocation(), 
												user1.getProfileImageURL(), user1.getDescription());
										UsersTweets(twitter,user1.getScreenName());
										database.InsertContacts(user.getScreenName(), user1.getScreenName());
										// insert the user data into database
									}
								}

							}
							
							
							queryinfo.put("retweet", retweetinfo);   // create the map 
							JsonArray.add(queryinfo);     // put the map into a jsonarray
						}
				}
				
				
				
				
			}
				catch (Exception te) 
				{
					te.printStackTrace();
					System.out.println("Failed to search tweets:" +
					te.getMessage());
					System.exit(-1);
				}
		
				Gson gson = new Gson();    // make the jsonarray a json string
				jsonpack = gson.toJson(JsonArray);   
				return jsonpack;
			}
		private String jsonpack;
		private ArrayList<Map> JsonArray = new ArrayList();
		
		public void UsersTweets(Twitter twitter,String userscreenname) throws SQLException, TwitterException
		{
			DatabaseConnection database = new DatabaseConnection();   
			Query query= new Query("from:"+userscreenname);
			
			query.setCount(100);  // number of limiting the query 
			
			QueryResult result = twitter.search(query);
			
			//it cycles on the tweets
			List<Status> tweets = result.getTweets();
			
			
			for (Status tweet : tweets) 
			{ ///gets the user
				User user = tweet.getUser();
				
				String user_screenname = String.valueOf(user.getScreenName());
				String tweet_time = String.valueOf(tweet.getCreatedAt());
				String tweet_sid = String.valueOf(tweet.getId());
				String tweet_isretweet = null;
				if(tweet.isRetweet() == true)
					tweet_isretweet = "1";
				else
					tweet_isretweet = "0";
				database.InsertTweets(user_screenname, tweet.getText(), tweet_time, tweet_sid, tweet_isretweet);
			}
			
		}
		
	}
	
